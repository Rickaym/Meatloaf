from setuptools import setup

setup(
    name="Meatloaf",
    version="0.0.0.a",
    description="To be released...",
    author="Rickaym",
    #long_description=long_description,
    #long_description_content_type="text/markdown",
    #url="https://github.com/Rickaym/{}".format(prj_name),
    #},
    license="MIT",
    python_requires=">=2.7",
    packages=[],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Natural Language :: English",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3.9",
    ],
)
